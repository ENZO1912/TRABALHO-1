class Soma20{
    public static void main(String[] args) {

        int soma= 0;

        for (int i = 500; i >= 0; i -= 50) {
            soma = soma + i;
        }

        System.out.println("A SOMA E: " + soma);
    }
}
import java.util.Scanner;

class Contagem18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int inicio, fim, incremento;

        System.out.print("DIITE O PRIMEIRO VALOR: ");
        inicio = scanner.nextInt();

        System.out.print("DIGITE O ULTIMO VALOR: ");
        fim = scanner.nextInt();

        System.out.print("DIGITE O INCREMENTO Digite o incremento: ");
        incremento = scanner.nextInt();

        System.out.print("CORNTAGEM: ");

        if (inicio < fim) {
            for (int i = inicio; i <= fim; i += incremento) {
                System.out.print(i + " ");
            }
        } else {
            for (int i = inicio; i >= fim; i -= incremento) {
                System.out.print(i + " ");
            }
        }

        System.out.print("ACABOU!");
    }
}
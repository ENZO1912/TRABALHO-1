class Soma19 {
    public static void main(String[] args) {

        int soma = 0;

        for (int i = 6; i <= 100; i += 2) {
            soma = soma + i;
        }

        System.out.println("A SOMA E: " + soma);
    }
}
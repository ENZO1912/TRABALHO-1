import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Tringulo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double tamanho1, tamanho2, tamanho3;

        System.out.print("DIGITE 3 SEGMENTOS DE UMA RETA: ");
        tamanho1 = scanner.nextDouble();
        tamanho2 = scanner.nextDouble();
        tamanho3 = scanner.nextDouble();

        if (tamanho1 + tamanho2 > tamanho3 &&
                tamanho1 + tamanho3 > tamanho2 &&
                tamanho2 + tamanho3 > tamanho1) {

            if (tamanho1 == tamanho2 && tamanho2 == tamanho3) {
                System.out.println("TRIANGULO EQUILATERO");

            } else if (tamanho1 == tamanho2 ||
                    tamanho1 == tamanho3 ||
                    tamanho2 == tamanho3) {
                System.out.println("TRIANGULO ISOSCELES");

            } else {
                System.out.println("TRIANGULO ESCALENO");

            }else{
                System.out.println("NAO E POSSIVEL SER UM TRIANGULO");
            }
        }
    }
}
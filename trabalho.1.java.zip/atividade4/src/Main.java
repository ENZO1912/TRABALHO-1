import java.util.Scanner;

class Par_ou_IMPAR {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

 int num;

 System.out.print("DIGITE UM NUMERO INTEIRO: ");
 num = scanner.nextInt();

        if (num % 2 == 0){

        System.out.print("ESSE NUMERO E PAR");

        }else{
            System.out.print("ESSE NUMERO E IMPAR");
        }
    }
}
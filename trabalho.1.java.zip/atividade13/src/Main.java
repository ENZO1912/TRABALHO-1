class Contagem13 {
    public static void main(String[] args) {

        for (int i = 10; i >= 3; i--) {
            System.out.print(i + " ");

            if (i == 3) {
                System.out.print("ACABOU!");
            }
        }
    }
}
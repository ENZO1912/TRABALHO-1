//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class atividade21{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int num;
        int soma = 0;

        for (int i = 1; i <= 7; i++) {
            System.out.print("DIGITE O " + i + " NUMERO: ");
            num = scanner.nextInt();
            soma += num;
        }

        System.out.println("A SOMA DOS 7 NUMEROS E: " + soma);

    }
}
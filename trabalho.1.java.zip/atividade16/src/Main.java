
class Contagem16 {
    public static void main(String[] args) {

        for (int i = 30 ; i >= 1; i -= 1) {
            System.out.print(i + " ");

            if (i % 4 == 0) {
            System.out.print("[" + i + "] ");
            }else {
                System.out.print(i+ " ");
            }
        }
    }
}


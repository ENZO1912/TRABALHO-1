//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.time.Year;
import java.util.Scanner;

class AlisamentoMilitar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int anoNascimento;
        int anoAtual = Year.now().getValue();
        int idade;

        System.out.print("DIGITE O ANO DE NASCIMENTO: ");
        anoNascimento = scanner.nextInt();

        idade = anoAtual - anoNascimento;

        System.out.println("SUA IDADE E: " + idade + " ANOS");

        if (idade < 18) {
            int falta = 18 - idade;
            System.out.println("AINDA NAO PODE ALISTAR");
            System.out.println("FALTAM " + falta + " ANO(s) PARA O ALISATAMENTO");
        } else if (idade == 18) {
            System.out.println("PODE SE ALISTAR ESSE ANO");
        } else {
            int passou = idade - 18;
            System.out.println("JA PASSOU DO TEMPO DO ALISTAMENTO");
            System.out.println("JA SE PASSARAM " + passou + " ANO(s) DO ALISTAMENTO");
        }
    }
}
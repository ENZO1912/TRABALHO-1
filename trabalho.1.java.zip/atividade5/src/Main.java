//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

class AnoBissesto{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int ano;
        System.out.print("DIGITE UM ANO PARA SABER SE E BISSESTO OU NAO: ");
        ano = scanner.nextInt();
        if ((ano % 400 == 0) || (ano % 4 == 0 && ano % 100 != 0)) {
            System.out.print("ESSE ANO E BISSESTO");

        } else{
            System.out.print("ESSE ANO NAO E BISSESTO");
        }
    }
}
import java.util.Scanner;
import java.time.Year;

class VerificarVoto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int anoNascimento;
        int anoAtual = Year.now().getValue();
        int idade;

        System.out.print("DIGITE SEU ANO DE NASCIMENTO: ");
        anoNascimento = scanner.nextInt();

        idade = anoAtual - anoNascimento;

        System.out.println("SUA IDADE E: " + idade + " " + "ANOS.");

        if (idade >= 16) {
            System.out.println("VOCE PODE VOTAR.");
        } else {
            System.out.println("VOCE AINDA NAO PODE VOTAR.");
        }

        scanner.close();
    }
}
import java.util.Scanner;

class Contagem17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int inicio, fim, incremento;

        System.out.print("DIGITE O PRIMEIRO VALOR: ");
        inicio = scanner.nextInt();

        System.out.print("DIGITE O ULTIMO VALOR: ");
        fim = scanner.nextInt();

        System.out.print("DIGITE O INCREMENTO: ");
        incremento = scanner.nextInt();

        System.out.print("CONTAGEM: ");

        for (int i = inicio; i <= fim; i += incremento) {
            System.out.print(i + " ");
        }

        System.out.print("ACABOU!");
    }
}
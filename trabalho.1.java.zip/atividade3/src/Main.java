import java.util.Scanner;

class MediaAlunos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nome = "";
        float nota1, nota2,media;

        System.out.print("DIGITE SEU NOME: ");
        nome = scanner.nextLine();

     System.out.print("DIGITE A PRIMEIRA NOTA: ");
        nota1 = scanner.nextFloat();

        System.out.print("DIGITE A SEGUNDA NOTA:" );
       nota2 = scanner.nextFloat();

        media = (nota1 + nota2) / 2;

 if (media > 7){
       System.out.print("FICOU ACIMA DA MEDIA " +nome+ " E SUA NOTA FOI: " + media);

    }else {
     System.out.print("NAO FICOU NA MEDIA: " + media);
    }
  }
}
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Distancia_Km_Valor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double km;
        double total;

System.out.print("QUAL A DISTANCIA QUE DESEJA PERCORRER KM: ");
        km = scanner.nextDouble();

       if (km <= 200){
           total = km * 0.50;

       } else {
           total = km * 0.45;
       }

        System.out.printf("O VALOR DA VIAGEM E: R$ %.2f" +, total);
    }
}
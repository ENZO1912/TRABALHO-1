import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Dia_Da_Mulher {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String nome;
        String genero;
        double precoOriginal, precoFinal, valorDesconto = 0;

        System.out.print("DIGITE SEU NOME: ");
        nome = scanner.nextLine();

        System.out.print("INFORME SEU GENERO MULHER OU HOMEM (F/M): ");
        genero = scanner.nextLine();

        System.out.print("DIGITE O VALOR DAS COMPRAS: ");
        precoOriginal = scanner.nextDouble();

        if (genero.equalsIgnoreCase("M")) {
        valorDesconto = precoOriginal * 0.08;

        } else  if (genero.equals("F")){
            valorDesconto = precoOriginal * 0.13;
        }else {
            System.out.print("INVALIDO");
        }

        precoFinal = precoOriginal - valorDesconto;

    System.out.print("\nCLIENTE:" +nome);
    System.out.printf("VALOR ORIGINA: R$%.2f \n", precoOriginal);
    System.out.printf("\nDESCONTO DE: R$%.2f \n", valorDesconto);
    System.out.printf("VALOR COM DESCONTO: R$ %.2f", precoFinal);
     }
        }
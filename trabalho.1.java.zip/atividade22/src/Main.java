import java.util.Scanner;
class Pa22 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int vetor[] = new int[10];
        int primeiro, razao, soma = 0;

        System.out.print("DIGITE O PRIMEIRO TERMO: ");
        primeiro = scanner.nextInt();

        System.out.print("DIGITE A RAZAO: ");
        razao = scanner.nextInt();

        vetor[0] = primeiro;

        for (int i = 1; i < 10; i++) {
            vetor[i] = vetor[i - 1] + razao;
        }

        System.out.print("PA: ");
        for (int i = 0; i < 10; i++) {
            System.out.print(vetor[i] + " ");
            soma = soma + vetor[i];
        }

        System.out.print("ACABOU!");

        System.out.print("\nSOMA: " + soma);
    }
}
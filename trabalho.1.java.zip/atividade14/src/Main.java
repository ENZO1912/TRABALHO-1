//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Contagem14 {
    public static void main(String[] args) {

        for (int i = 0; i <= 18; i += 3) {
            System.out.print(i + " ");

            if (i == 18) {
                System.out.print("ACABOU!");
            }
        }
    }
}

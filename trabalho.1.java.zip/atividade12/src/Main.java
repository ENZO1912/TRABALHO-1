class contagem_12 {
        public static void main(String[] args) {

            for (int i = 6; i < 12; i++) {
                System.out.printf("%d ", i);

                if (i == 11) {
                    System.out.printf("ACABOU!");
                }
            }
        }
    }
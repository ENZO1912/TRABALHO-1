import java.util.Scanner;

class multa {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            double velocidade;
            double multa = 0;

            System.out.print("DIGITE A VELOCIDADE DO CARRO (KM/H): ");
            velocidade = scanner.nextDouble();

            if (velocidade > 80) {
                double excesso = velocidade - 80;
                multa = excesso * 5;

                System.out.print("VOCE FOI MULTADO");
                System.out.printf("VALOR DA MULTA: R$ %.2f\n", multa);

            } else {
                System.out.print("VELOCIDADE DENTRO DO LIMITE");
            }
        }
    }
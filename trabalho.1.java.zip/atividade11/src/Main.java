import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Salario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String nome;
        int anos;
        double salario,aumento = 0,NovoSalario;

System.out.print("DIGITE SEU NOME: ");
nome = scanner.nextLine();

System.out.print("DIGITE SEU SALARIO: ");
        salario = scanner.nextDouble();

System.out.print("DIGITE QUANTOS ANOS TRABLHA NA EMPRESA?: ");
       anos = scanner.nextInt();

       if (anos < 3){
           aumento = salario * 0.03;

       } else if (anos < 10) {
           aumento = salario * 0.125;
           
       } else if (anos >= 10) {
           aumento = salario * 0.20;
       }

        NovoSalario = salario + aumento;

       System.out.print("\nFUNCIONARIO: " +nome);
        System.out.printf("\nSEU NOVO SALARIO E: R$ %.2f ", NovoSalario);

    }
}
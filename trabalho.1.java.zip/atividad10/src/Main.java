import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
class Terreno {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double area,largura,comprimento;

        System.out.print("DIGITE A LARGURA DO TERRENO: ");
        largura = scanner.nextDouble();

        System.out.print("DIGITE O COMPRIMENTO DO TERREN0: ");
        comprimento = scanner.nextDouble();

        area = largura * comprimento;

        if (area < 100){
            System.out.print("TERRNO POPULAR");

        } else if (area >= 100 && area <= 500) {
            System.out.print("TERRENO MASTER");

        } else if (area > 500) {
            System.out.print("TERRENO VIP");

        }
    }
}